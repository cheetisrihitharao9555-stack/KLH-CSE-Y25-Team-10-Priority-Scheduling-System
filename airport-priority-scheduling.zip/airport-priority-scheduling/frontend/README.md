# Airport Priority Scheduling Frontend
Run:
```powershell
npm install
npm run dev
```
The frontend expects FastAPI at `http://127.0.0.1:8000`.
