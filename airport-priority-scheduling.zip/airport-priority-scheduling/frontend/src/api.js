import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:8000/api",
  timeout: 10000,
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.code === "ECONNABORTED") {
      error.message = "The server took too long to respond. Check that the backend is running.";
    } else if (!error.response) {
      error.message = "Cannot connect to the backend. Start the Node.js server on port 8000.";
    }
    return Promise.reject(error);
  }
);

export const get = (path) => api.get(path).then((r) => r.data);
export const post = (path, data = {}) => api.post(path, data).then((r) => r.data);
export const login = (data) => post("/auth/login", data);
export const register = (data) => post("/auth/register", data);
