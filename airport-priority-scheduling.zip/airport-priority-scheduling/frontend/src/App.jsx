import React, { useEffect, useState } from "react";
import {
  Routes,
  Route,
  Link,
  Navigate,
  useNavigate,
} from "react-router-dom";
import { get, post, login, register } from "./api";

/* ================= NAVIGATION ================= */

const nav = [
  ["/dashboard", "Dashboard"],
  ["/submit", "Submit Operation"],
  ["/scheduler", "Live Scheduler"],
  ["/processes", "Process Monitor"],
  ["/resources", "Resources"],
  ["/memory", "Memory Management"],
  ["/ipc", "IPC Monitor"],
  ["/logs", "System Logs"],
  ["/reports", "Reports"],
  ["/co", "CO1–CO6 Modules"],
];

const errorText = (err) =>
  err?.response?.data?.detail || err?.message || "Something went wrong.";

/* ================= COMMON COMPONENTS ================= */

function PageTitle({ title, subtitle }) {
  return (
    <div className="page-title">
      <h1>{title}</h1>
      {subtitle && <p>{subtitle}</p>}
    </div>
  );
}

function Panel({ title, children }) {
  return (
    <section className="panel">
      {title && <h2>{title}</h2>}
      {children}
    </section>
  );
}

/* ================= HOME PAGE ================= */

function Home() {
  return (
    <div className="home">
      <div className="home-content">
        <small>AIRPORT OPERATIONS • OPERATING SYSTEMS</small>

        <h1>
          Airport Operation
          <br />
          <em>Priority Scheduling System</em>
        </h1>

        <p>
          A centralized airport operations platform for priority scheduling,
          process management, resource allocation, and real-time monitoring.
        </p>

        <div className="home-actions">
          <Link className="btn" to="/login">Login</Link>
          <Link className="btn alt" to="/register">Register</Link>
        </div>

        <div className="cards">
          {[
            "Process Management",
            "Priority Scheduling",
            "Resource Allocation",
            "Real-Time Monitoring",
          ].map((item) => (
            <div className="feature-card" key={item}>
              <h3>{item}</h3>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ================= LOGIN AND REGISTRATION ================= */

function AuthForm({
  title,
  fields,
  setFields,
  onSubmit,
  error,
  loading,
  extra,
}) {
  return (
    <div className="auth">
      <form
        className="auth-form"
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit(fields);
        }}
      >
        <Link to="/" className="brand-link">✈ APSS</Link>
        <h1>{title}</h1>
        <p>Airport Operation Priority Scheduling System</p>

        {fields.name !== undefined && (
          <input
            placeholder="Full name"
            value={fields.name}
            required
            onChange={(e) =>
              setFields({ ...fields, name: e.target.value })
            }
          />
        )}

        <input
          type="email"
          placeholder="Email address"
          value={fields.email}
          required
          onChange={(e) =>
            setFields({ ...fields, email: e.target.value })
          }
        />

        <input
          type="password"
          placeholder="Password"
          value={fields.password}
          required
          onChange={(e) =>
            setFields({ ...fields, password: e.target.value })
          }
        />

        {extra}

        <button className="btn" type="submit" disabled={loading}>
          {loading ? "Please wait..." : "Continue"}
        </button>

        {error && <p className="error">{error}</p>}

        {title === "System Login" ? (
          <p>New user? <Link to="/register">Create account</Link></p>
        ) : (
          <p>Already registered? <Link to="/login">Login</Link></p>
        )}

        <Link to="/" className="back-link">← Back to Home</Link>
      </form>
    </div>
  );
}

function Login() {
  const navigate = useNavigate();
  const [fields, setFields] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleLogin(data) {
    setError("");
    setLoading(true);

    try {
      const result = await login(data);

      if (!result?.user) {
        throw new Error("Login response did not contain a user.");
      }

      localStorage.setItem("airportUser", JSON.stringify(result.user));
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setError(errorText(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthForm
      title="System Login"
      fields={fields}
      setFields={setFields}
      onSubmit={handleLogin}
      error={error}
      loading={loading}
    />
  );
}

function Register() {
  const navigate = useNavigate();
  const [fields, setFields] = useState({
    name: "",
    email: "",
    password: "",
    role: "User",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleRegister(data) {
    setError("");
    setLoading(true);

    try {
      await register(data);
      navigate("/login", { replace: true });
    } catch (err) {
      setError(errorText(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthForm
      title="Create Account"
      fields={fields}
      setFields={setFields}
      onSubmit={handleRegister}
      error={error}
      loading={loading}
      extra={
        <select
          value={fields.role}
          aria-label="Account role"
          onChange={(e) =>
            setFields({ ...fields, role: e.target.value })
          }
        >
          <option value="User">User</option>
          <option value="Admin">Admin</option>
        </select>
      }
    />
  );
}

/* ================= MAIN LAYOUT ================= */

function Layout({ children }) {
  const navigate = useNavigate();

  function logout() {
    localStorage.removeItem("airportUser");
    navigate("/login", { replace: true });
  }

  return (
    <div className="shell">
      <aside className="sidebar">
        <Link to="/dashboard" className="sidebar-brand">
          <h2>✈ APSS</h2>
          <small>Airport OS Control</small>
        </Link>

        <nav>
          {nav.map(([path, label]) => (
            <Link key={path} to={path}>{label}</Link>
          ))}
        </nav>

        <button className="logout-button" onClick={logout}>
          Logout
        </button>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div>
            <b>Airport Operation Priority Scheduling System</b>
            <span>OS-Based Process &amp; Resource Management</span>
          </div>
        </header>

        <div className="page-content">{children}</div>
      </main>
    </div>
  );
}

/* ================= DATA TABLE ================= */

function TablePage({ title, path, cols }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;

    async function load() {
      try {
        const result = await get(path);
        if (active) {
          setData(Array.isArray(result) ? result : []);
          setError("");
        }
      } catch (err) {
        if (active) setError(errorText(err));
      } finally {
        if (active) setLoading(false);
      }
    }

    load();
    return () => { active = false; };
  }, [path]);

  return (
    <div>
      {title && <PageTitle title={title} />}

      <Panel>
        {loading && <p>Loading...</p>}
        {error && <p className="error">{error}</p>}

        {!loading && !error && data.length === 0 && (
          <p>No records available.</p>
        )}

        {!loading && data.length > 0 && (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  {cols.map((col) => (
                    <th key={col}>{col.replaceAll("_", " ")}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.map((item, index) => (
                  <tr key={item.pid ?? item.id ?? index}>
                    {cols.map((col) => (
                      <td key={col}>
                        {String(item[col] ?? "—")}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
}

/* ================= DASHBOARD ================= */

function Dashboard() {
  const [processes, setProcesses] = useState([]);
  const [resources, setResources] = useState([]);
  const [memory, setMemory] = useState({});
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;

    async function load() {
      try {
        const [p, r, m] = await Promise.all([
          get("/processes"),
          get("/resources"),
          get("/memory"),
        ]);

        if (active) {
          setProcesses(Array.isArray(p) ? p : []);
          setResources(Array.isArray(r) ? r : []);
          setMemory(m || {});
          setError("");
        }
      } catch (err) {
        if (active) setError(errorText(err));
      }
    }

    load();
    const timer = setInterval(load, 5000);

    return () => {
      active = false;
      clearInterval(timer);
    };
  }, []);

  const stats = [
    ["Total Processes", processes.length],
    ["Running", processes.filter((p) => p.state === "RUNNING").length],
    ["Ready", processes.filter((p) => p.state === "READY").length],
    ["Waiting", processes.filter((p) => p.state === "WAITING").length],
    ["Terminated", processes.filter((p) => p.state === "TERMINATED").length],
  ];

  return (
    <div>
      <PageTitle
        title="Operations Dashboard"
        subtitle="Live airport process and resource monitoring."
      />

      {error && <p className="error">{error}</p>}

      <div className="stats">
        {stats.map(([label, value]) => (
          <div className="stat" key={label}>
            <small>{label}</small>
            <b>{value}</b>
          </div>
        ))}
      </div>

      <div className="grid">
        <Panel title="Priority Queue">
          {processes
            .filter((p) => p.state !== "TERMINATED")
            .sort((a, b) => a.priority - b.priority)
            .map((p) => (
              <p key={p.pid}>
                P{p.priority} · {p.flight_number} · {p.state}
              </p>
            ))}
          {processes.length === 0 && <p>No active processes.</p>}
        </Panel>

        <Panel title="Resources">
          {resources.map((r, i) => (
            <p key={r.resource_id ?? i}>
              {r.resource_name} — {r.status}
            </p>
          ))}
          {resources.length === 0 && <p>No resource data available.</p>}
        </Panel>

        <Panel title="Memory Monitor">
          <h2>{memory.used_memory_mb ?? 0} MB</h2>
          <p>Used memory</p>
          <p>Available: {memory.available_memory_mb ?? 0} MB</p>
          <p>Usage: {memory.usage_percent ?? 0}%</p>
        </Panel>
      </div>
    </div>
  );
}

/* ================= SUBMIT OPERATION ================= */

function Submit() {
  const [fields, setFields] = useState({
    flight_number: "",
    airline: "",
    source: "",
    destination: "Hyderabad",
    operation_type: "Normal Landing",
  });
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setMessage("");
    setError("");
    setLoading(true);

    try {
      const result = await post("/processes", fields);
      setMessage(
        `Operation created. PID: ${result?.pid ?? "created"}; Priority: ${
          result?.priority ?? "assigned"
        }.`
      );
    } catch (err) {
      setError(errorText(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <PageTitle title="Submit Airport Operation" />

      <Panel>
        <form className="form" onSubmit={submit}>
          {[
            ["flight_number", "Flight Number"],
            ["airline", "Airline"],
            ["source", "Source Airport"],
            ["destination", "Destination Airport"],
          ].map(([key, label]) => (
            <input
              key={key}
              placeholder={label}
              required
              value={fields[key]}
              onChange={(e) =>
                setFields({ ...fields, [key]: e.target.value })
              }
            />
          ))}

          <label htmlFor="operation">Operation Type</label>
          <select
            id="operation"
            value={fields.operation_type}
            onChange={(e) =>
              setFields({ ...fields, operation_type: e.target.value })
            }
          >
            {[
              "Emergency Landing",
              "Medical Emergency",
              "Critical Aircraft Problem",
              "International Landing",
              "Normal Landing",
              "Takeoff",
              "Maintenance",
              "Ground Service",
            ].map((x) => <option key={x}>{x}</option>)}
          </select>

          <button className="btn" disabled={loading}>
            {loading ? "Submitting..." : "Submit Operation"}
          </button>

          {message && <p className="success">{message}</p>}
          {error && <p className="error">{error}</p>}
        </form>
      </Panel>
    </div>
  );
}

/* ================= SCHEDULER ================= */

function Scheduler() {
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function action(name) {
    setMessage("");
    setError("");
    setBusy(true);

    try {
      const result = await post(`/scheduler/${name}`);
      setMessage(result?.message || `${name} request completed.`);
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  async function emergency() {
    setMessage("");
    setError("");
    setBusy(true);

    try {
      const result = await post("/scheduler/emergency");
      setMessage(result?.message || "Emergency simulation requested.");
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <PageTitle
        title="Live Priority Scheduler"
        subtitle="Control airport process scheduling."
      />

      <Panel title="Scheduling Pipeline">
        <div className="flow">
          NEW → READY QUEUE → PRIORITY SCHEDULER → RUNNING → WAITING → TERMINATED
        </div>

        <div className="scheduler-actions">
          <button className="btn" disabled={busy} onClick={() => action("start")}>
            Start
          </button>
          <button className="btn alt" disabled={busy} onClick={() => action("pause")}>
            Pause
          </button>
          <button className="btn alt" disabled={busy} onClick={() => action("reset")}>
            Reset
          </button>
          <button className="btn danger" disabled={busy} onClick={emergency}>
            Emergency Simulation
          </button>
        </div>

        {busy && <p>Processing request...</p>}
        {message && <p className="success">{message}</p>}
        {error && <p className="error">{error}</p>}
      </Panel>

      <TablePage
        title="Scheduled Processes"
        path="/processes"
        cols={["pid", "flight_number", "operation_type", "priority", "state", "remaining_time"]}
      />
    </div>
  );
}

/* ================= OS MODULES ================= */

function CO() {
  const modules = [
    ["CO1", "OS as a Service Layer", "system_calls.c"],
    ["CO2", "Process Management", "process_management.c"],
    ["CO3", "Inter-Process Communication", "pipe_demo.c / signal_demo.c / socket_demo.c"],
    ["CO4", "Memory Management", "memory_management.c"],
    ["CO5", "File Systems", "file_system.c"],
    ["CO6", "Concurrency", "thread_demo.c / mutex_demo.c / semaphore_demo.c"],
  ];

  return (
    <div>
      <PageTitle
        title="Operating Systems Modules"
        subtitle="CO1–CO6 demonstrations"
      />
      <div className="co">
        {modules.map(([code, title, program]) => (
          <Panel key={code} title={`${code} — ${title}`}>
            <p>Example program: {program}</p>
            <p>Operating system concepts demonstrated through airport scenarios.</p>
          </Panel>
        ))}
      </div>
    </div>
  );
}

/* ================= REPORTS ================= */

function Reports() {
  const reports = [
    ["Priority Scheduling", "Review process priorities and execution order."],
    ["Process States", "Review running, ready, waiting, and terminated processes."],
    ["Resource Allocation", "Review airport resource status."],
    ["IPC Events", "Review inter-process communication activity."],
    ["Memory Management", "Review memory usage and availability."],
    ["System Logs", "Review recorded system events."],
  ];

  return (
    <div>
      <PageTitle title="Reports" subtitle="System monitoring and reporting." />
      <div className="grid">
        {reports.map(([title, description]) => (
          <Panel key={title} title={title}>
            <p>{description}</p>
          </Panel>
        ))}
      </div>
    </div>
  );
}

/* ================= PROTECTED ROUTES ================= */

function ProtectedLayout() {
  if (!localStorage.getItem("airportUser")) {
    return <Navigate to="/login" replace />;
  }

  return (
    <Layout>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/submit" element={<Submit />} />
        <Route path="/scheduler" element={<Scheduler />} />

        <Route
          path="/processes"
          element={
            <TablePage
              title="Process Monitor"
              path="/processes"
              cols={["pid", "flight_number", "operation_type", "priority", "state", "remaining_time"]}
            />
          }
        />

        <Route
          path="/resources"
          element={
            <TablePage
              title="Resource Monitor"
              path="/resources"
              cols={["resource_id", "resource_name", "resource_type", "status", "current_process_id"]}
            />
          }
        />

        <Route
          path="/memory"
          element={
            <TablePage
              title="Memory Monitor"
              path="/memory"
              cols={["total_memory_mb", "used_memory_mb", "available_memory_mb", "usage_percent"]}
            />
          }
        />

        <Route
          path="/ipc"
          element={
            <TablePage
              title="IPC Monitor"
              path="/ipc"
              cols={["ipc_id", "sender_pid", "receiver_pid", "ipc_type", "message"]}
            />
          }
        />

        <Route
          path="/logs"
          element={
            <TablePage
              title="System Logs"
              path="/logs"
              cols={["log_id", "event_type", "description"]}
            />
          }
        />

        <Route path="/reports" element={<Reports />} />
        <Route path="/co" element={<CO />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Layout>
  );
}

/* ================= APP ================= */

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/*" element={<ProtectedLayout />} />
    </Routes>
  );
}

export default App;