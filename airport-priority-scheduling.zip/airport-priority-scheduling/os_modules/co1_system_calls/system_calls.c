#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
int main(void){
    const char msg[]="CO1: Scheduler requests an OS service.\n";
    ssize_t n=write(STDOUT_FILENO,msg,sizeof(msg)-1);
    if(n<0) perror("write");
    int fd=STDOUT_FILENO;
    printf("File descriptor: %d\n",fd);
    char buffer[32];
    if(read(-1,buffer,sizeof(buffer))<0) printf("errno=%d (%s)\n",errno,strerror(errno));
    return 0;
}
