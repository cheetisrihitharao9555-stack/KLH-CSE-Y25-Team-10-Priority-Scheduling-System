#include <stdio.h>
#include <signal.h>
#include <unistd.h>
void handler(int s){printf("Scheduler received signal %d: emergency notification.\n",s);}
int main(){struct sigaction sa={0};sa.sa_handler=handler;sigaction(SIGUSR1,&sa,NULL);printf("PID=%d. Send SIGUSR1 from another terminal.\n",getpid());kill(getpid(),SIGUSR1);return 0;}
