#include <stdio.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <string.h>
int main(){const char *path="/tmp/airport_socket";int s=socket(AF_UNIX,SOCK_STREAM,0);if(s<0){perror("socket");return 1;}struct sockaddr_un a={0};a.sun_family=AF_UNIX;strncpy(a.sun_path,path,sizeof(a.sun_path)-1);unlink(path);bind(s,(struct sockaddr*)&a,sizeof(a));listen(s,1);printf("Unix domain socket created: %s\n",path);close(s);unlink(path);return 0;}
