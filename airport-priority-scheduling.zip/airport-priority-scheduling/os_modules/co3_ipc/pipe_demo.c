#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
int main(){int p[2];pipe(p);pid_t pid=fork();if(pid==0){close(p[0]);write(p[1],"EK501 has landed",16);close(p[1]);_exit(0);}close(p[1]);char b[64]={0};read(p[0],b,63);printf("Ground Service received: %s\n",b);close(p[0]);wait(NULL);return 0;}
