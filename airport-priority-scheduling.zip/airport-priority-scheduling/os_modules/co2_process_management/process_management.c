#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
int main(){
    pid_t pid=fork();
    if(pid<0){perror("fork");return 1;}
    if(pid==0){
        printf("Child PID=%d: executing airport worker.\n",getpid());
        execlp("echo","echo","CO2: exec() executed by child process",NULL);
        _exit(1);
    }
    printf("Parent PID=%d waiting for child %d.\n",getpid(),pid);
    waitpid(pid,NULL,0);
    printf("waitpid(): child completed. exit() from parent.\n");
    exit(0);
}
