#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
int main(){const char *f="scheduler.log";int fd=open(f,O_CREAT|O_RDWR|O_TRUNC,0644);if(fd<0){perror("open");return 1;}const char *msg="EK501 -> runway 1 allocated\n";write(fd,msg,28);lseek(fd,0,SEEK_SET);char b[64]={0};read(fd,b,63);printf("FD=%d; read(): %s",fd,b);close(fd);return 0;}
