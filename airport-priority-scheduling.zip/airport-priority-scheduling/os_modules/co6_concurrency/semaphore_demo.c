#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
sem_t runways;
void* flight(void* x){sem_wait(&runways);printf("Flight entered a runway.\n");printf("Flight completed.\n");sem_post(&runways);return NULL;}
int main(){sem_init(&runways,0,2);pthread_t a,b,c;pthread_create(&a,NULL,flight,NULL);pthread_create(&b,NULL,flight,NULL);pthread_create(&c,NULL,flight,NULL);pthread_join(a,NULL);pthread_join(b,NULL);pthread_join(c,NULL);sem_destroy(&runways);return 0;}
