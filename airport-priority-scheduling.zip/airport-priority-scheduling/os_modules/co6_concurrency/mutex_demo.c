#include <pthread.h>
#include <stdio.h>
pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;int gate=0;
void* reserve(void* x){pthread_mutex_lock(&lock);if(!gate){gate=1;printf("Gate reserved safely by thread.\n");}else printf("Gate already occupied; request waits/fails.\n");pthread_mutex_unlock(&lock);return NULL;}
int main(){pthread_t a,b;pthread_create(&a,NULL,reserve,NULL);pthread_create(&b,NULL,reserve,NULL);pthread_join(a,NULL);pthread_join(b,NULL);return 0;}
