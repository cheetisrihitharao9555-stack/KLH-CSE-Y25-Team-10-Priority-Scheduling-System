#include <pthread.h>
#include <stdio.h>
void* worker(void* x){printf("Thread %ld: processing airport task.\n",(long)pthread_self());return NULL;}
int main(){pthread_t a,b;pthread_create(&a,NULL,worker,NULL);pthread_create(&b,NULL,worker,NULL);pthread_join(a,NULL);pthread_join(b,NULL);return 0;}
