#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>
int main(){size_t n=4096;char *p=malloc(n);if(!p)return 1;p[0]='A';printf("malloc(): %zu bytes allocated, first byte=%c\n",n,p[0]);free(p);void *m=mmap(NULL,n,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(m==MAP_FAILED){perror("mmap");return 1;}((char*)m)[0]='M';printf("mmap(): page allocated, first byte=%c\n",((char*)m)[0]);munmap(m,n);printf("free/munmap(): memory released.\n");return 0;}
