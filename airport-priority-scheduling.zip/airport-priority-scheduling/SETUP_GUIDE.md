# Quick setup (Windows / PowerShell)

1. Import `database/airport.sql` in MySQL Workbench. It recreates the APSS tables; back up existing data first.
2. Backend terminal:
   ```powershell
   cd backend
   Copy-Item .env.example .env
   ```
   Edit `.env` and set `DB_PASSWORD`, then run:
   ```powershell
   npm install
   npm run dev
   ```
3. Frontend terminal:
   ```powershell
   cd frontend
   npm install
   npm run dev
   ```
4. Open `http://localhost:5173`.

API health check: `http://localhost:8000/api/health`

No Python, venv, pip, FastAPI, or Uvicorn commands are used.
