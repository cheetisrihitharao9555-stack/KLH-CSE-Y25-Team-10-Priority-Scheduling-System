-- ============================================================
-- AIRPORT OPERATION PRIORITY SCHEDULING SYSTEM
-- MySQL Database
-- ============================================================

-- 1. CREATE DATABASE
CREATE DATABASE IF NOT EXISTS airport_priority_system;

USE airport_priority_system;


-- ============================================================
-- 2. USERS TABLE
-- ============================================================

DROP TABLE IF EXISTS system_logs;
DROP TABLE IF EXISTS ipc_logs;
DROP TABLE IF EXISTS memory_allocations;
DROP TABLE IF EXISTS scheduling_logs;
DROP TABLE IF EXISTS resources;
DROP TABLE IF EXISTS processes;
DROP TABLE IF EXISTS flights;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('User', 'Admin') NOT NULL DEFAULT 'User',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ============================================================
-- 3. FLIGHTS TABLE
-- ============================================================

CREATE TABLE flights (
    flight_id INT AUTO_INCREMENT PRIMARY KEY,
    flight_number VARCHAR(20) NOT NULL UNIQUE,
    airline VARCHAR(100) NOT NULL,
    source VARCHAR(100) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    scheduled_time DATETIME NOT NULL,
    status ENUM(
        'Scheduled',
        'Ready',
        'Running',
        'Delayed',
        'Completed',
        'Emergency',
        'Cancelled'
    ) DEFAULT 'Scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ============================================================
-- 4. PROCESSES TABLE
-- ============================================================

CREATE TABLE processes (
    process_id INT AUTO_INCREMENT PRIMARY KEY,

    flight_id INT NOT NULL,

    operation_type ENUM(
        'Emergency Landing',
        'Medical Emergency',
        'Critical Aircraft Problem',
        'International Landing',
        'Normal Landing',
        'Takeoff',
        'Maintenance',
        'Ground Service'
    ) NOT NULL,

    priority INT NOT NULL,

    arrival_time DATETIME NOT NULL,

    burst_time INT NOT NULL,

    remaining_time INT NOT NULL,

    state ENUM(
        'NEW',
        'READY',
        'RUNNING',
        'WAITING',
        'TERMINATED'
    ) DEFAULT 'NEW',

    parent_process_id INT NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (flight_id)
        REFERENCES flights(flight_id)
        ON DELETE CASCADE,

    FOREIGN KEY (parent_process_id)
        REFERENCES processes(process_id)
        ON DELETE SET NULL,

    CHECK (priority BETWEEN 1 AND 5),
    CHECK (burst_time >= 0),
    CHECK (remaining_time >= 0)
);


-- ============================================================
-- 5. RESOURCES TABLE
-- ============================================================

CREATE TABLE resources (
    resource_id INT AUTO_INCREMENT PRIMARY KEY,

    resource_type ENUM(
        'Runway',
        'Gate',
        'Ground Service',
        'Maintenance Team'
    ) NOT NULL,

    resource_name VARCHAR(100) NOT NULL,

    status ENUM(
        'AVAILABLE',
        'OCCUPIED',
        'MAINTENANCE'
    ) DEFAULT 'AVAILABLE',

    current_process_id INT NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (current_process_id)
        REFERENCES processes(process_id)
        ON DELETE SET NULL
);


-- ============================================================
-- 6. SCHEDULING LOGS
-- ============================================================

CREATE TABLE scheduling_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,

    process_id INT NOT NULL,

    old_state VARCHAR(30),

    new_state VARCHAR(30),

    old_priority INT,

    new_priority INT,

    event VARCHAR(255) NOT NULL,

    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (process_id)
        REFERENCES processes(process_id)
        ON DELETE CASCADE
);


-- ============================================================
-- 7. MEMORY ALLOCATIONS
-- ============================================================

CREATE TABLE memory_allocations (
    memory_id INT AUTO_INCREMENT PRIMARY KEY,

    process_id INT NOT NULL,

    allocated_memory INT NOT NULL,

    memory_status ENUM(
        'ALLOCATED',
        'RELEASED'
    ) DEFAULT 'ALLOCATED',

    allocation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    release_time TIMESTAMP NULL,

    FOREIGN KEY (process_id)
        REFERENCES processes(process_id)
        ON DELETE CASCADE
);


-- ============================================================
-- 8. IPC LOGS
-- ============================================================

CREATE TABLE ipc_logs (
    ipc_id INT AUTO_INCREMENT PRIMARY KEY,

    sender_pid INT NOT NULL,

    receiver_pid INT NOT NULL,

    ipc_type ENUM(
        'PIPE',
        'SIGNAL',
        'SOCKET',
        'SHARED_MEMORY'
    ) NOT NULL,

    message VARCHAR(500) NOT NULL,

    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (sender_pid)
        REFERENCES processes(process_id)
        ON DELETE CASCADE,

    FOREIGN KEY (receiver_pid)
        REFERENCES processes(process_id)
        ON DELETE CASCADE
);


-- ============================================================
-- 9. SYSTEM LOGS
-- ============================================================

CREATE TABLE system_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,

    event_type ENUM(
        'LOGIN',
        'PROCESS',
        'SCHEDULER',
        'RESOURCE',
        'MEMORY',
        'IPC',
        'SYSTEM',
        'ERROR'
    ) NOT NULL,

    description VARCHAR(500) NOT NULL,

    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ============================================================
-- 10. INSERT USERS
-- ============================================================

INSERT INTO users
(name, email, password, role)
VALUES
('Airport Admin',
 'admin@airport.com',
 'admin123',
 'Admin'),

('Priyadarshini',
 'priya@airport.com',
 'priya123',
 'User'),

('Rahul',
 'rahul@airport.com',
 'rahul123',
 'User'),

('Arjun',
 'arjun@airport.com',
 'arjun123',
 'User');


-- ============================================================
-- 11. INSERT FLIGHTS
-- ============================================================

INSERT INTO flights
(flight_number, airline, source, destination, scheduled_time, status)
VALUES

('AI101',
 'Air India',
 'Delhi',
 'Hyderabad',
 '2026-10-06 10:30:00',
 'Scheduled'),

('EK501',
 'Emirates',
 'Dubai',
 'Hyderabad',
 '2026-10-06 10:45:00',
 'Emergency'),

('UK801',
 'Vistara',
 'Mumbai',
 'Hyderabad',
 '2026-10-06 11:00:00',
 'Scheduled'),

('6E205',
 'IndiGo',
 'Bangalore',
 'Hyderabad',
 '2026-10-06 11:20:00',
 'Scheduled'),

('AI302',
 'Air India',
 'Chennai',
 'Hyderabad',
 '2026-10-06 11:40:00',
 'Scheduled');


-- ============================================================
-- 12. INSERT PROCESSES
-- ============================================================

INSERT INTO processes
(
    flight_id,
    operation_type,
    priority,
    arrival_time,
    burst_time,
    remaining_time,
    state
)
VALUES

(
    1,
    'Normal Landing',
    3,
    '2026-10-06 10:01:00',
    10,
    10,
    'RUNNING'
),

(
    2,
    'Emergency Landing',
    1,
    '2026-10-06 10:03:00',
    5,
    5,
    'READY'
),

(
    3,
    'International Landing',
    2,
    '2026-10-06 10:04:00',
    8,
    8,
    'READY'
),

(
    4,
    'Takeoff',
    4,
    '2026-10-06 10:05:00',
    12,
    12,
    'WAITING'
),

(
    5,
    'Maintenance',
    4,
    '2026-10-06 10:06:00',
    15,
    15,
    'WAITING'
);


-- ============================================================
-- 13. INSERT AIRPORT RESOURCES
-- ============================================================

INSERT INTO resources
(resource_type, resource_name, status, current_process_id)
VALUES

('Runway',
 'Runway 1',
 'OCCUPIED',
 1),

('Runway',
 'Runway 2',
 'AVAILABLE',
 NULL),

('Gate',
 'Gate A1',
 'OCCUPIED',
 1),

('Gate',
 'Gate A2',
 'AVAILABLE',
 NULL),

('Gate',
 'Gate B1',
 'AVAILABLE',
 NULL),

('Ground Service',
 'Ground Team 1',
 'AVAILABLE',
 NULL),

('Ground Service',
 'Ground Team 2',
 'AVAILABLE',
 NULL),

('Maintenance Team',
 'Maintenance Team 1',
 'AVAILABLE',
 NULL);


-- ============================================================
-- 14. INSERT SCHEDULING LOGS
-- ============================================================

INSERT INTO scheduling_logs
(
    process_id,
    old_state,
    new_state,
    old_priority,
    new_priority,
    event
)
VALUES

(
    1,
    'READY',
    'RUNNING',
    3,
    3,
    'Runway 1 allocated to AI101'
),

(
    2,
    'NEW',
    'READY',
    1,
    1,
    'Emergency EK501 entered priority queue'
),

(
    3,
    'NEW',
    'READY',
    2,
    2,
    'UK801 added to ready queue'
),

(
    4,
    'NEW',
    'WAITING',
    4,
    4,
    '6E205 waiting for runway'
);


-- ============================================================
-- 15. INSERT MEMORY ALLOCATIONS
-- ============================================================

INSERT INTO memory_allocations
(
    process_id,
    allocated_memory,
    memory_status
)
VALUES

(1, 512, 'ALLOCATED'),
(2, 256, 'ALLOCATED'),
(3, 384, 'ALLOCATED'),
(4, 256, 'ALLOCATED'),
(5, 128, 'ALLOCATED');


-- ============================================================
-- 16. INSERT IPC LOGS
-- ============================================================

INSERT INTO ipc_logs
(
    sender_pid,
    receiver_pid,
    ipc_type,
    message
)
VALUES

(
    2,
    1,
    'PIPE',
    'Emergency flight EK501 notification sent'
),

(
    2,
    1,
    'SIGNAL',
    'Preemption signal sent to AI101'
),

(
    1,
    3,
    'SOCKET',
    'Runway status communication'
);


-- ============================================================
-- 17. INSERT SYSTEM LOGS
-- ============================================================

INSERT INTO system_logs
(event_type, description)
VALUES

(
    'SYSTEM',
    'Airport Priority Scheduling System started'
),

(
    'LOGIN',
    'Admin logged into the system'
),

(
    'PROCESS',
    'Process PID 101 created for AI101'
),

(
    'PROCESS',
    'Process PID 102 created for emergency EK501'
),

(
    'SCHEDULER',
    'Priority scheduler started'
),

(
    'SCHEDULER',
    'Emergency process EK501 assigned Priority 1'
),

(
    'RESOURCE',
    'Runway 1 allocated'
),

(
    'MEMORY',
    'Memory allocated to airport processes'
),

(
    'IPC',
    'Emergency notification sent through IPC'
);


-- ============================================================
-- 18. VERIFY DATABASE
-- ============================================================

SHOW TABLES;


-- ============================================================
-- 19. CHECK USERS
-- ============================================================

SELECT * FROM users;


-- ============================================================
-- 20. CHECK FLIGHTS
-- ============================================================

SELECT * FROM flights;


-- ============================================================
-- 21. CHECK PROCESSES
-- ============================================================

SELECT * FROM processes;


-- ============================================================
-- 22. CHECK RESOURCES
-- ============================================================

SELECT * FROM resources;


-- ============================================================
-- 23. CHECK SCHEDULING LOGS
-- ============================================================

SELECT * FROM scheduling_logs;


-- ============================================================
-- 24. CHECK MEMORY
-- ============================================================

SELECT * FROM memory_allocations;


-- ============================================================
-- 25. CHECK IPC
-- ============================================================

SELECT * FROM ipc_logs;


-- ============================================================
-- 26. CHECK SYSTEM LOGS
-- ============================================================

SELECT * FROM system_logs;