# Airport Operation Priority Scheduling System

This version keeps the original React frontend and replaces the FastAPI/Python backend with Node.js, Express, and MySQL.

## Requirements
- Node.js 20 or newer
- MySQL 8
- VS Code (optional)

## 1. Database
Open `database/airport.sql` in MySQL Workbench and execute it against a fresh `airport_priority_system` database. **The script drops and recreates the project's tables**, so back up any existing data first.

The SQL seeds demo users:
- `admin@airport.com` / `admin123`
- `priya@airport.com` / `priya123`
- `rahul@airport.com` / `rahul123`
- `arjun@airport.com` / `arjun123`

The backend supports these original plain-text seed passwords and upgrades a user's password to bcrypt after their first successful login. New registrations are stored using bcrypt.

## 2. Backend
Open a terminal at the project root:

```powershell
cd backend
Copy-Item .env.example .env
```

Edit `backend/.env` and enter your MySQL password in `DB_PASSWORD`. Then:

```powershell
npm install
npm run dev
```

The API runs at `http://localhost:8000`. Test it at `http://localhost:8000/api/health`.

## 3. Frontend
Open a second terminal at the project root:

```powershell
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

## Features / API
- Register and login: `/api/auth/register`, `/api/auth/login`
- Flights: `/api/flights`
- Airport operation submission and process monitor: `/api/processes`
- Live priority scheduler: `/api/scheduler/start`, `/pause`, `/reset`, `/emergency`, `/queue`
- Resources: `/api/resources`
- Memory monitor: `/api/memory`
- IPC monitor: `/api/ipc`
- System logs: `/api/logs`

Priority mapping:
- P1: Emergency Landing, Medical Emergency, Critical Aircraft Problem
- P2: International Landing
- P3: Normal Landing, Takeoff
- P4: Maintenance, Ground Service

## Notes
- This project has no Python backend or Python runtime dependency.
- Do not upload `.env` files or passwords to GitHub.
- Keep both terminal windows running while using the app.
