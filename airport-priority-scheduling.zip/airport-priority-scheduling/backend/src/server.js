import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import { pool, query, one, insert } from "./db.js";

dotenv.config();
const app = express();
const PORT = Number(process.env.PORT || 8000);
app.use(cors({ origin: [process.env.FRONTEND_ORIGIN || "http://localhost:5173", "http://127.0.0.1:5173"], credentials: true }));
app.use(express.json());

const asyncRoute = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const logEvent = (type, description) => insert(
  "INSERT INTO system_logs(event_type, description) VALUES (?, ?)", [type, description]
);
const priorities = {
  "Emergency Landing": 1, "Medical Emergency": 1, "Critical Aircraft Problem": 1,
  "International Landing": 2, "Normal Landing": 3, "Takeoff": 3,
  "Maintenance": 4, "Ground Service": 4
};
const bursts = {
  "Emergency Landing": 8, "Medical Emergency": 7, "Critical Aircraft Problem": 9,
  "International Landing": 10, "Normal Landing": 12, "Takeoff": 10,
  "Maintenance": 14, "Ground Service": 11
};

app.get("/", (_req, res) => res.json({ service: "Airport Operation Priority Scheduling System", api: "/api/health" }));
app.get("/api/health", asyncRoute(async (_req, res) => {
  await one("SELECT 1 AS ok");
  res.json({ status: "healthy", database: "connected", service: "airport-priority-scheduling-node" });
}));

// Authentication: accepts the original SQL seed accounts and hashes new passwords.
app.post("/api/auth/register", asyncRoute(async (req, res) => {
  const { name, email, password, role = "User" } = req.body || {};
  if (!name || String(name).trim().length < 2 || !email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !password || String(password).length < 6) {
    return res.status(400).json({ detail: "Enter a valid name, email, and password (at least 6 characters)." });
  }
  if (!["User", "Admin"].includes(role)) return res.status(400).json({ detail: "Role must be User or Admin." });
  const exists = await one("SELECT user_id FROM users WHERE email = ?", [String(email).trim().toLowerCase()]);
  if (exists) return res.status(409).json({ detail: "Email is already registered" });
  const hashed = await bcrypt.hash(String(password), 10);
  const userId = await insert("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",
    [String(name).trim(), String(email).trim().toLowerCase(), hashed, role]);
  await logEvent("SYSTEM", `New ${role} registered: ${email}`);
  res.status(201).json({ message: "Registration successful", user_id: userId });
}));

app.post("/api/auth/login", asyncRoute(async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ detail: "Email and password are required." });
  const row = await one("SELECT user_id,name,email,password,role FROM users WHERE email = ?", [String(email).trim().toLowerCase()]);
  if (!row) return res.status(401).json({ detail: "Invalid email or password" });
  let valid = false;
  if (String(row.password).startsWith("$2")) valid = await bcrypt.compare(String(password), row.password);
  else valid = String(row.password) === String(password); // compatible with the original seeded demo accounts
  if (!valid) return res.status(401).json({ detail: "Invalid email or password" });
  if (!String(row.password).startsWith("$2")) {
    const hashed = await bcrypt.hash(String(password), 10);
    await query("UPDATE users SET password = ? WHERE user_id = ?", [hashed, row.user_id]);
  }
  const user = { user_id: row.user_id, name: row.name, email: row.email, role: row.role };
  await logEvent("LOGIN", `${user.email} logged in`);
  res.json({ message: "Login successful", user });
}));

app.get("/api/flights", asyncRoute(async (_req, res) => {
  res.json(await query("SELECT * FROM flights ORDER BY scheduled_time, flight_id"));
}));
app.post("/api/flights", asyncRoute(async (req, res) => {
  const { flight_number, airline, source, destination, scheduled_time, status = "Scheduled" } = req.body || {};
  if (!flight_number || !airline || !source || !destination) return res.status(400).json({ detail: "Flight details are required." });
  const exists = await one("SELECT flight_id FROM flights WHERE flight_number = ?", [flight_number]);
  if (exists) return res.status(409).json({ detail: "Flight number already exists." });
  const id = await insert("INSERT INTO flights(flight_number,airline,source,destination,scheduled_time,status) VALUES(?,?,?,?,?,?)",
    [flight_number, airline, source, destination, scheduled_time || new Date(), status]);
  res.status(201).json({ flight_id: id });
}));

async function processRows() {
  return query(`SELECT p.process_id AS pid, f.flight_number, p.operation_type, p.priority,
    p.arrival_time, p.burst_time, p.remaining_time, p.state, p.parent_process_id
    FROM processes p JOIN flights f ON f.flight_id=p.flight_id ORDER BY p.process_id`);
}
app.get("/api/processes", asyncRoute(async (_req, res) => res.json(await processRows())));
app.get("/api/processes/:pid", asyncRoute(async (req, res) => {
  const row = await one(`SELECT p.process_id AS pid, f.flight_number, p.operation_type, p.priority,
    p.arrival_time, p.burst_time, p.remaining_time, p.state, p.parent_process_id
    FROM processes p JOIN flights f ON f.flight_id=p.flight_id WHERE p.process_id=?`, [Number(req.params.pid)]);
  if (!row) return res.status(404).json({ detail: "Process ID not found" });
  res.json(row);
}));
app.post("/api/processes", asyncRoute(async (req, res) => {
  const { flight_number, airline, source, destination, operation_type } = req.body || {};
  if (!flight_number || !airline || !source || !destination || !operation_type) return res.status(400).json({ detail: "Complete all airport operation fields." });
  if (!(operation_type in priorities)) return res.status(400).json({ detail: "Unknown operation type." });
  let flight = await one("SELECT flight_id FROM flights WHERE flight_number=?", [flight_number]);
  let flightId;
  if (!flight) {
    flightId = await insert("INSERT INTO flights(flight_number,airline,source,destination,scheduled_time,status) VALUES(?,?,?,?,NOW(),'Scheduled')",
      [flight_number, airline, source, destination]);
  } else flightId = flight.flight_id;
  const priority = priorities[operation_type], burst = bursts[operation_type] || 10;
  const pid = await insert(`INSERT INTO processes(flight_id,operation_type,priority,arrival_time,burst_time,remaining_time,state)
    VALUES(?,?,?,NOW(),?,?,'READY')`, [flightId, operation_type, priority, burst, burst]);
  await insert("INSERT INTO memory_allocations(process_id,allocated_memory,memory_status) VALUES(?, ?, 'ALLOCATED')", [pid, Math.max(128, Math.round(burst * 32))]);
  await logEvent("PROCESS", `Created PID ${pid} for ${flight_number}; priority P${priority}`);
  res.status(201).json({ pid, flight_number, priority, state: "READY", message: "Priority automatically assigned by the system." });
}));

app.get("/api/resources", asyncRoute(async (_req, res) => {
  res.json(await query("SELECT * FROM resources ORDER BY resource_type,resource_id"));
}));
app.get("/api/memory", asyncRoute(async (_req, res) => {
  const rows = await query("SELECT process_id,allocated_memory,memory_status FROM memory_allocations WHERE memory_status='ALLOCATED'");
  const total = 4096, used = rows.reduce((sum, r) => sum + Number(r.allocated_memory), 0);
  res.json({ total_memory_mb: total, used_memory_mb: used, available_memory_mb: Math.max(0,total-used), usage_percent: Number((used*100/total).toFixed(2)), process_memory: rows });
}));
app.get("/api/ipc", asyncRoute(async (_req, res) => res.json(await query("SELECT * FROM ipc_logs ORDER BY timestamp DESC LIMIT 100"))));
app.get("/api/logs", asyncRoute(async (_req, res) => res.json(await query("SELECT * FROM system_logs ORDER BY timestamp DESC LIMIT 100"))));
app.get("/api/scheduler/queue", asyncRoute(async (_req, res) => {
  res.json(await query(`SELECT p.process_id AS pid,f.flight_number,p.operation_type,p.priority,p.arrival_time,
    p.burst_time,p.remaining_time,p.state,p.parent_process_id FROM processes p JOIN flights f ON f.flight_id=p.flight_id
    WHERE p.state IN ('READY','WAITING','RUNNING') ORDER BY p.priority,p.arrival_time,p.process_id`));
}));

let schedulerRunning = false;
let schedulerTimer = null;
let tickBusy = false;
async function schedulerTick() {
  if (tickBusy) return;
  tickBusy = true;
  try {
    const current = await one("SELECT process_id,priority,remaining_time FROM processes WHERE state='RUNNING' ORDER BY process_id LIMIT 1");
    const next = await one("SELECT process_id,priority FROM processes WHERE state='READY' ORDER BY priority,arrival_time,process_id LIMIT 1");
    let active = current;
    if (next && (!current || Number(next.priority) < Number(current.priority))) {
      if (current) {
        await query("UPDATE processes SET state='READY' WHERE process_id=?", [current.process_id]);
        await insert("INSERT INTO scheduling_logs(process_id,old_state,new_state,old_priority,new_priority,event) VALUES(?,?,?,?,?,?)",
          [current.process_id,"RUNNING","READY",current.priority,current.priority,"Higher-priority process caused preemption."]);
      }
      await query("UPDATE processes SET state='RUNNING' WHERE process_id=?", [next.process_id]);
      await insert("INSERT INTO scheduling_logs(process_id,old_state,new_state,old_priority,new_priority,event) VALUES(?,?,?,?,?,?)",
        [next.process_id,"READY","RUNNING",next.priority,next.priority,"Scheduler selected highest priority process."]);
      active = await one("SELECT process_id,priority,remaining_time FROM processes WHERE process_id=?", [next.process_id]);
    }
    if (active) {
      const remaining = Math.max(0, Number(active.remaining_time) - 1);
      if (remaining === 0) {
        await query("UPDATE processes SET remaining_time=0,state='TERMINATED' WHERE process_id=?", [active.process_id]);
        await insert("INSERT INTO scheduling_logs(process_id,old_state,new_state,old_priority,new_priority,event) VALUES(?,?,?,?,?,?)",
          [active.process_id,"RUNNING","TERMINATED",active.priority,active.priority,"Process completed."]);
        await query("UPDATE resources SET status='AVAILABLE',current_process_id=NULL WHERE current_process_id=?", [active.process_id]);
        await query("UPDATE memory_allocations SET memory_status='RELEASED',release_time=NOW() WHERE process_id=?", [active.process_id]);
      } else {
        await query("UPDATE processes SET remaining_time=? WHERE process_id=?", [remaining,active.process_id]);
      }
    }
  } finally { tickBusy = false; }
}
app.post("/api/scheduler/start", asyncRoute(async (_req, res) => {
  if (!schedulerRunning) {
    schedulerRunning = true;
    schedulerTimer = setInterval(() => schedulerTick().catch(err => console.error("Scheduler tick:", err.message)), 1000);
  }
  await logEvent("SCHEDULER", "Scheduler started");
  res.json({ message: "Scheduler started.", running: true });
}));
app.post("/api/scheduler/pause", asyncRoute(async (_req, res) => {
  schedulerRunning = false;
  if (schedulerTimer) clearInterval(schedulerTimer);
  schedulerTimer = null;
  await logEvent("SCHEDULER", "Scheduler paused");
  res.json({ message: "Scheduler paused.", running: false });
}));
app.post("/api/scheduler/reset", asyncRoute(async (_req, res) => {
  schedulerRunning = false;
  if (schedulerTimer) clearInterval(schedulerTimer);
  schedulerTimer = null;
  await query("UPDATE resources SET status='AVAILABLE',current_process_id=NULL");
  await query("UPDATE processes SET state='READY',remaining_time=burst_time WHERE state <> 'TERMINATED'");
  await logEvent("SCHEDULER", "Scheduler reset");
  res.json({ message: "Scheduler reset. Non-terminated processes returned to READY.", running: false });
}));
app.post("/api/scheduler/emergency", asyncRoute(async (_req, res) => {
  const ai = await one(`SELECT p.process_id,p.priority FROM processes p JOIN flights f ON f.flight_id=p.flight_id
    WHERE f.flight_number='AI101' ORDER BY p.process_id LIMIT 1`);
  let ek = await one(`SELECT p.process_id,p.priority FROM processes p JOIN flights f ON f.flight_id=p.flight_id
    WHERE f.flight_number='EK501' AND p.operation_type='Emergency Landing' ORDER BY p.process_id LIMIT 1`);
  if (!ek) {
    let flight = await one("SELECT flight_id FROM flights WHERE flight_number='EK501'");
    if (!flight) flight = await one("SELECT flight_id FROM flights ORDER BY flight_id LIMIT 1");
    if (!flight) return res.status(400).json({ detail: "Create a flight before running the emergency simulation." });
    const pid = await insert(`INSERT INTO processes(flight_id,operation_type,priority,arrival_time,burst_time,remaining_time,state,parent_process_id)
      VALUES(?,'Emergency Landing',1,NOW(),8,8,'READY',?)`, [flight.flight_id, ai?.process_id || null]);
    ek = { process_id: pid, priority: 1 };
    await insert("INSERT INTO memory_allocations(process_id,allocated_memory,memory_status) VALUES(?,256,'ALLOCATED')", [pid]);
  } else {
    await query("UPDATE processes SET priority=1,state='READY',remaining_time=burst_time WHERE process_id=?", [ek.process_id]);
  }
  if (ai) {
    await query("UPDATE processes SET state='READY' WHERE process_id=?", [ai.process_id]);
    await insert("INSERT INTO scheduling_logs(process_id,old_state,new_state,old_priority,new_priority,event) VALUES(?,?,?,?,?,?)",
      [ai.process_id,"RUNNING","READY",ai.priority,ai.priority,"AI101 preempted by emergency operation."]);
  }
  await query("UPDATE processes SET state='RUNNING' WHERE process_id=?", [ek.process_id]);
  await insert("INSERT INTO scheduling_logs(process_id,old_state,new_state,old_priority,new_priority,event) VALUES(?,?,?,?,?,?)",
    [ek.process_id,"READY","RUNNING",1,1,"Emergency operation detected. Priority 1 assigned."]);
  const runway = await one("SELECT resource_id FROM resources WHERE resource_type='Runway' AND status='AVAILABLE' LIMIT 1");
  if (runway) await query("UPDATE resources SET status='OCCUPIED',current_process_id=? WHERE resource_id=?", [ek.process_id, runway.resource_id]);
  await logEvent("SCHEDULER", "Emergency operation assigned Priority 1");
  res.json({ message: "Emergency operation detected. Priority 1 assigned. Existing process preempted when applicable.", running: schedulerRunning });
}));

app.use((err, _req, res, _next) => {
  console.error(err);
  if (err?.code === "ER_DUP_ENTRY") return res.status(409).json({ detail: "This record already exists." });
  if (err?.code === "ER_NO_SUCH_TABLE" || err?.code === "ECONNREFUSED" || err?.code === "ER_ACCESS_DENIED_ERROR") {
    return res.status(500).json({ detail: "Database connection failed. Check backend/.env and import database/airport.sql." });
  }
  res.status(500).json({ detail: err?.message || "Internal server error" });
});

const server = app.listen(PORT, async () => {
  console.log(`Airport Scheduling API running at http://localhost:${PORT}`);
  try { await one("SELECT 1"); console.log("MySQL database connected."); }
  catch (err) { console.error("MySQL connection failed:", err.message); }
});
process.on("SIGINT", async () => { if (schedulerTimer) clearInterval(schedulerTimer); await pool.end(); server.close(() => process.exit(0)); });
